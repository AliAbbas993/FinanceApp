
function signup(){
    var user = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var password =document.getElementById('password').value;
    var confrmPassword = document.getElementById('confirmPassword').value;
  
    if(user=='' || email=='' || password=='')
    {
        document.getElementById('error-name').innerHTML='UserName can not be blank'
        document.getElementById('error-mail').innerHTML='mail can not be blank'
        document.getElementById('error-password').innerHTML='password can not be blank'
    }
    //regex variable for email
    var re = /^(([^<>()[]\.,;:s@"]+(.[^<>()[]\.,;:s@"]+)*)|(".+"))@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}])|(([a-zA-Z-0-9]+.)+[a-zA-Z]{2,}))$/igm;

    //username attributes
    if(user.length<=3)
        {  
            document.getElementById('error-name').innerHTML='UserName should be greater than 3'
            return false
        }
    else
        {
            localStorage.setItem('User',user)
        }

    if(!re.test(email.val())){
        document.getElementById('error-mail').innerHTML='mail can not be blank';
        return false;
    }
    else{
        return true;
    }
    //mail attribute
    // if(email[email.length-1]=='@'){
    //     document.getElementById('error-mail').innerHTML='Mail should not end at @'
    //     return false
    // }
    // var atSign=email.indexOf('@')
    // for(var i=0;i<email.length;i++)
    // {
    //     if(atSign ==-1)
    //         {
    //             document.getElementById('error-mail').innerHTML='Invalid Email'
    //             return false
    //         }
    //     else if(atSign<1)
    //         {
    //             document.getElementById('error-mail').innerHTML='Mail should not be start with @'   
    //             return false
    //         }       
    // }   
    localStorage.setItem('Mail',email)
    
    //password attributes
    var upperCase=/[A-Z]/
    var lowerCase=/[a-z]/
    var num=/[0-9]/
    if(password.length<=6)
    {
        document.getElementById('error-password').innerHTML='Password length should be greater than 6'
    }
    for(var i=0;i<password.length;i++)
    {
        if(password.search(upperCase)==-1 || password.search(lowerCase)==-1 || password.search(num)==-1)
        {
            document.getElementById('error-password').innerHTML='Choose a strong Password containing uppercase , lowercase &numbers '
            return false
        }
    }
    localStorage.setItem('Password',password)

    //confirm password attribute
    if(confrmPassword != password)
    {
        document.getElementById('error-confirmPassword').innerHTML='Password Does Not Match'
        return false
    }
    else
    {
        return true
    }



    firebase.auth().createUserWithEmailAndPassword(user, email)
    .then(function(){
        alert('signup successfully');
    })
    .catch(function(error) {
      // Handle Errors here.
      var errorCode = error.code;
      var errorMessage = error.message;
      alert(errorMessage);
      // ...
    });
};


function loginForm(){
    var name = document.getElementById('loginName').value
    var pass = document.getElementById('loginPass').value
    var getName = localStorage.getItem('User')
    var getPass = localStorage.getItem('Password')

    if( name!=getName ||  pass!=getPass )
    {
        document.getElementById('show-error').innerHTML='Username / Password is incorrect'
        return false
    }
    else
    {
        alert('Login Succesfull !');
        return true
    }
}